/// <reference path="../typings/tsd.d.ts" />
// import * as socketio from 'socket.io';
module nets {
    // import io = require("socket.io");
    export class SIO extends egret.Sprite{
        private isVideoPlay:boolean = false;
        private video:egret.Video;
        private socket:SocketIOClient.Socket;
        constructor() {
            super();
            
            this.once(egret.Event.ADDED_TO_STAGE,this.init,this);
            // console.log(111,socket)
        }
        private init(){
            var gp = new eui.Group();
            gp.y=10;
            gp.width = this.stage.stageWidth;
            gp.height = this.stage.stageHeight;
            var ly = new eui.TileLayout();
            ly.horizontalGap = 10;
            ly.verticalGap = 10;
            gp.layout = ly;         
             
            // var socket = io('http://localhost:8080');
            // var socket = io('http://127.0.0.1:5050');
            // var socket = io('http://10.0.6.109:5050');
            var socket = io('http://localhost:5050');
            this.socket = socket;
            
            var btn = new eui.Button();
            btn.label = 'login';
            // gp.addChild(btn);
            btn.addEventListener(egret.TouchEvent.TOUCH_TAP,()=>{
                socket.emit('login', {userid:"okok", username:"jeff"});    
            },this);            
            
            var btn = new eui.Button();
            btn.label = 'message';
            // gp.addChild(btn);
            btn.addEventListener(egret.TouchEvent.TOUCH_TAP,()=>{
                socket.emit('message', {userid:"okok", username:"jeff",message:'me'+Math.random()*500});    
            },this);
            
            var idx = 1;
             var btn = new eui.Button();
            btn.label = 'bitmap';
            // gp.addChild(btn);
            btn.addEventListener(egret.TouchEvent.TOUCH_TAP,()=>{
                var tex:egret.Texture = RES.getRes('p'+idx);
                console.log('idx',idx)
                var b64 = tex.toDataURL('image/jpeg',new egret.Rectangle(0, 0, tex.textureWidth, tex.textureHeight))
                socket.emit('bitmap', b64);   
                idx++; 
                if(idx>3)idx=1;
            },this);
            
            var vdx = 1;
            var btn = new eui.Button();
            btn.label = 'play';
            gp.addChild(btn);            
            
            var self = this;
            btn.addEventListener(egret.TouchEvent.TOUCH_TAP,()=>{
                self.removeEventListener(egret.Event.ENTER_FRAME,self.onPlayVideo,self);
                if(this.video){
                    this.video.close();
                    this.removeChild(this.video);
                }
                var video = new egret.Video();
                this.video = video;
                video.fullscreen = false;
                video.width = 200;
                video.height = 200;
                this.addChild(video);
                
                // if(video.load){
                //     video.close();
                // }
                this.isVideoPlay = false;
                var videoName = `/resource/video/video${vdx}.mp4`
                vdx++;
                console.log(videoName)
                video.load(videoName);
                video.addEventListener(egret.Event.COMPLETE,()=>{
                    console.log(11)
                    setTimeout(function() {
                        video.play(); 
                        self.isVideoPlay = true;
                        self.addEventListener(egret.Event.ENTER_FRAME,self.onPlayVideo,self);
                    }, 1000);
                    
                },this)
                
                // var tex:egret.Texture = RES.getRes(videoName);
                
                
                // var b64 = tex.toDataURL('image/jpeg',new egret.Rectangle(0, 0, tex.textureWidth, tex.textureHeight))
                // socket.emit('bitmap', b64);   
                if(vdx>3)vdx=1;
            },this);
            
            socket.on('login', function(o){
				console.log('login',o)
			});
            
            var bmp = new egret.Bitmap();
            bmp.y = 100;
            this.addChild(bmp);
            var img: HTMLImageElement = new Image();
            var texture = new egret.Texture();
            var bmp = new egret.Bitmap(texture);
            this.addChild(bmp)
            img.onload=()=>{
                texture._setBitmapData(img);
            }
            socket.on('bitmap', function(o){
                // bmp.bitmapData = o;
				// console.log('bitmap')
                // img.src = o;
			});            
            this.addChild(gp);            
        }
        private onPlayVideo(){
            // if(this.isVideoPlay){
                
            // }
            var tex = new egret.Texture();
                tex._setBitmapData(this.video.bitmapData);
                // var bmp = new egret.Bitmap()
                
                var b64 = tex.toDataURL('image/jpeg',new egret.Rectangle(0, 0, tex.textureWidth, tex.textureHeight))
                // console.log(b64)
                this.socket.emit('bitmap', b64); 
        }
    }
}