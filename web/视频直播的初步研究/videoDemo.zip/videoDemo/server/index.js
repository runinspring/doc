var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

app.get('/', function(req, res){
	res.send('<h1>Welcome Realtime Server</h1>');
});
io.on('connection', function(socket){
	console.log('a user connected');
  socket.on('login', function(obj){
    console.log('login')
    io.emit('login',obj)
  })
  socket.on('disconnect', function(){
    console.log('disconnect')
  })
  socket.on('message', function(obj){
    console.log('message',obj)
  })
  socket.on('bitmap', function(obj){
    // console.log('bitmap')
    io.emit('bitmap',obj)
  })
})
http.listen(5050, function(){
	console.log('listening on *:5050');
});